DEBUG = True
MONGO_DATABASE = 'surprise'
MONGO_IP = 'localhost'

DIDOK_COLLECTION = 'didok'
EVENT_COLLECTION = 'event'
TOWNS_COLLECTION = 'towns'
